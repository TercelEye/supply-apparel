// @codekit-append "../libs/jquery/jquery.min.js";
// @codekit-append "../libs/jquery_ui/jquery-ui.min.js";
// @codekit-append "../libs/bootstrap/js/bootstrap.min.js";
// @codekit-append "../libs/date_picker/picker.js";
// @codekit-append "../libs/semantic/js/dropdown.min.js";
// @codekit-append "../libs/semantic/js/transition.min.js";
// @codekit-append "custom.js";